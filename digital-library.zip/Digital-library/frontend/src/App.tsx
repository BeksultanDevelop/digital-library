import Navbar from './components/Navbar'
import Sidebar from './components/Sidebar'
import AppRoutes from './routes/AppRoutes'

function App() {
	return (
		<>
			<Sidebar />

			<Navbar />
			<AppRoutes />
		</>
	)
}

export default App
