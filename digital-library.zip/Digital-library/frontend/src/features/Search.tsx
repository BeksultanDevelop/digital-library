import { useState } from 'react'

const books = [
	'Origin',
	'The Fury',
	'Gerald`s Game',
	'Don`t Turn Around',
	'The Maidens',
]

const Search = () => {
	const [search, setSearch] = useState('')
	const filteredBooks = books.filter(book =>
		book.toLowerCase().includes(search.toLowerCase()),
	)

	return (
		<div className=''>
			<input
				type='text'
				placeholder='Search book...'
				value={search}
				onChange={e => setSearch(e.target.value)}
				className='w-full px-14 py-1 rounded-xl bg-[#232839] outline-none'
			/>
			{search.trim() !== '' && (
				<div className='mt-5 flex flex-col gap-2'>
					{filteredBooks.map((book, index) => (
						<div className='bg-[#ffffff] px-10 py-1 rounded-xl' key={index}>
							{book}
						</div>
					))}
				</div>
			)}
		</div>
	)
}

export default Search
