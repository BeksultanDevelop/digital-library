import { useState } from 'react'

const languages = ['EN', 'RU', 'KZ']

const Language = () => {
	const [language, setLanguage] = useState('EN')
	return (
		<div className=''>
			<select
				value={language}
				onChange={e => setLanguage(e.target.value)}
				className='px-8 py-1 rounded-xl bg-[#232839]'
			>
				{languages.map(lang => (
					<option className='' key={lang} value={lang}>
						{lang}
					</option>
				))}
			</select>
		</div>
	)
}

export default Language
