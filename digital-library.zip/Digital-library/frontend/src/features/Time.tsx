import { useEffect, useState } from 'react'

const Time = () => {
	const [time, setTime] = useState(new Date())
	useEffect(() => {
		const interval = setInterval(() => {
			setTime(new Date())
		}, 1000)
		return () => clearInterval(interval)
	}, [])
	const formattedTime = time.toLocaleTimeString()
	const formattedDate = time.toLocaleDateString()
	return (
		<div className='flex py-1 px-4 rounded-xl gap-3 bg-[#232839]'>
			<div className=''>{formattedTime}</div>
			<div className="border-r border-[#4a5568]"></div>
			<div className=''>{formattedDate} </div>
		</div>
	)
}

export default Time
