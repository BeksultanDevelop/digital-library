import { Link } from 'react-router-dom'
import Language from '../features/Language'
import Search from '../features/Search'
import Time from '../features/Time'

const Navbar = () => {
	return (
		<nav className='flex gap-10 py-10 px-10 items-center'>
			<Search />
			<Language />
			<Time />
			<Link to='/Profile'>Profile</Link>
		</nav>
	)
}

export default Navbar
