import { Link } from 'react-router-dom'

const Sidebar = () => {
	return (
		<div className='w-64 bg-[rgba(255,255,255,0.02)] h-screen flex flex-col items-center text-white p-5 fixed left-0 top-0 gap-20'>
			<img src='/Logo.svg' alt='' className='' />

			<nav className='flex flex-col gap-4 text-left'>
				<Link to='/' className='hover:bg-zinc-800 p-2 rounded-lg transition'>
					Home
				</Link>

				<Link
					to='/login'
					className='hover:bg-zinc-800 p-2 rounded-lg transition'
				>
					Search
				</Link>

				<Link
					to='/register'
					className='hover:bg-zinc-800 p-2 rounded-lg transition'
				>
					My Shelf
				</Link>
			</nav>
		</div>
	)
}

export default Sidebar
