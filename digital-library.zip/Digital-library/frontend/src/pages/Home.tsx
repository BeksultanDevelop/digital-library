const Home = () => {
	return (
		<div className=''>
			<h1>Главная страница</h1>
		</div>
	)
}

export default Home
