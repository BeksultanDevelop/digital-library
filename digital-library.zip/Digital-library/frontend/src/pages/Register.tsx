const Register = () => {
  return (
    <div>
      Enter23
    </div>
  );
}

export default Register;